import sqlite3

#1- Criando a DB

conexao = sqlite3.connect("titulo.db")
